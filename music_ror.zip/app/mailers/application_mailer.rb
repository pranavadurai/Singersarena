class ApplicationMailer < ActionMailer::Base
  default from: 'Singersarena'
  layout 'mailer'
end
