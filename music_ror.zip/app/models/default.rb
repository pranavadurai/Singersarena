class Default < ApplicationRecord
end
