require 'test_helper'

class FollowerDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
