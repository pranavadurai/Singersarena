require 'test_helper'

class DefaultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
